package com.app.ws.api.ResourceServer.security;


import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;


@EnableWebSecurity
public class SecurityConfiguration {
    @Bean
    SecurityFilterChain configure(HttpSecurity httpSecurity) throws Exception{
        httpSecurity.authorizeHttpRequests(authz->
                        authz
                                .requestMatchers(HttpMethod.GET,"/users/status/check")
                                .hasAuthority("SCOPE_profile")
                                //.hasRole("Developer")
                                .anyRequest().authenticated())
                .oauth2ResourceServer(oauth2-> oauth2.jwt(jwtConfigurer -> {}));
        return httpSecurity.build();
    }


}
