package com.app.ws.api.ResourceServer.security;

import org.jspecify.annotations.Nullable;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class KeyclockRoleConverter implements Converter<Jwt, Collection<GrantedAuthority>> {
   /*
   "realm_access": {
        "roles": [
        "default-roles-devrealm",
                "offline_access",
                "Developer",
                "uma_authorization"
    ]
    */

    @Override
    public @Nullable Collection<GrantedAuthority> convert(Jwt jwt) {
        Map<String,Object> realmAccess= (Map<String, Object>) jwt.getClaims().get("realm_access");
        if (realmAccess==null || realmAccess.isEmpty()){
            return new ArrayList<>();
        }
        Collection<GrantedAuthority> grantedAuthorities = ((List<String>) realmAccess.get("roles"))
                .stream().map(roleName-> "ROLE_" + roleName)
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());
        return grantedAuthorities;
    }

    @Override
    public <U> Converter<Jwt, U> andThen(Converter<? super Collection<GrantedAuthority>, ? extends U> after) {
        return Converter.super.andThen(after);
    }
}
